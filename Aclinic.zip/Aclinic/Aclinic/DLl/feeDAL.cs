using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public static class feeDAL
    {
       public static void insFeeByFee(fee feeinfo)
       {
           string sql = ("insert into fee (fee_Money,fee_Med,fee_MedMoney,fee_Doctor,fee_Date) values (@fee_Money,@fee_Med,@fee_MedMoney,@fee_Doctor,@fee_Date)");
           SqlParameter[] prams = new SqlParameter[] 
            {
                 new SqlParameter("@fee_Money",feeinfo.FeeMoney),
                 new SqlParameter("@fee_Med",feeinfo.FeeMed),
                 
                 new SqlParameter("@fee_MedMoney",feeinfo.FeeMedMoney),
                 
                 new SqlParameter("@fee_Doctor",feeinfo.FeeDoctor),
                 new SqlParameter("@fee_Date",feeinfo.FeeDate)
            };
           int ins = SqlHelper.ExecuteCommand(sql, prams);
       }
    }
}
