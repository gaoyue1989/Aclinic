using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public static class medicinalDAL
    {
        public static List<medicinal> GetallMed()
        /// <summary>
        /// �������ҩƷ��Ϣ
        /// </summary>
        /// <returns></returns>
        {
            List<medicinal> med = new List<medicinal>();
            string sql = "select * from medicinal";
            using (DataTable dt = SqlHelper.GetDataSet(sql))
            {
                foreach (DataRow row in dt.Rows)
                {
                    medicinal medinfo = new medicinal();
                    if (row["med_Name"].ToString() != null)
                    { 
                        medinfo.MedName = row["med_Name"].ToString(); 
                    }
                 
                    medinfo.MedAmount = Convert.ToInt32( row["med_Amount"].ToString());
                    medinfo.MedID = Convert.ToInt32(row["med_ID"].ToString());
                 
                    medinfo.MedTypeID = Convert.ToInt32(row["med_TypeID"].ToString());
             
                    medinfo.Mome = row["med_Mome"].ToString();
                    med.Add(medinfo);
                }
            }
            return med;
        }

        public static DataTable GetallMed1()
        {
            string sql = "select * from medicinal";
            DataTable dt = SqlHelper.GetDataSet(sql);
            return dt;
            

 
        }    
        public static medicinal GatMedinfoBYmedName(string name)
        {
            medicinal med = new medicinal();
            string sql = "select * from medicinal where med_Name=@med_Name";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_Name", name) };
            using (DataTable dt = SqlHelper.GetDataSet(sql, prams))
            {
                foreach (DataRow row in dt.Rows)
                {
                    medicinal medinfo = new medicinal();
                    if (row["med_Name"].ToString() != null)
                    {
                        medinfo.MedName = row["med_Name"].ToString();
                    }

                    medinfo.MedAmount = Convert.ToInt32(row["med_Amount"].ToString());
                    medinfo.MedID = Convert.ToInt32(row["med_ID"].ToString());
                   
                 
                  
                    medinfo.Mome = row["med_Mome"].ToString();
                    med = medinfo;
 
                }
 
            }
            return med;
        }
        public static DataTable Getalldoctor()
        {
            string sql = "select * from doctor";
            DataTable dt = SqlHelper.GetDataSet(sql);
            return dt;
        }
        public static int GatNumBYMedName(string name)
        {
            int Num;
            medprice price = new medprice();
            string sql = "select med_Amount from medicinal where med_Name=@med_Name ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_Name", name) };
            Num = SqlHelper.GetScalarInt(sql, prams);
            return Num;

 
        }

        public static double GetPriceBYMedID(int id)
        {
            double price1;
            med_useless price = new med_useless();
            string sql = "select  * from med_useless where med_ID=@med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", id) };
           using (DataTable dt = SqlHelper.GetDataSet(sql, prams))
           {
               
               DataTable dt1 = new DataTable();
               dt1 = dt;
               DataView dv = dt1.DefaultView;
               dv.Sort = "med_uselessdate asc"; 
               dt1 = dv.ToTable();
               price1 = Convert.ToDouble(dt1.Rows[0]["med_buyprice"]);
           }
           return price1;
        }
        public static int GetnumBYMedID(int id)
        {
            int num;
            med_useless price = new med_useless();
            string sql = "select  * from med_useless where med_ID=@med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", id) };
            using (DataTable dt = SqlHelper.GetDataSet(sql, prams))
            {

                DataTable dt1 = new DataTable();
                dt1 = dt;
                DataView dv = dt1.DefaultView;
                dv.Sort = "med_uselessdate asc";
                dt1 = dv.ToTable();
                num = Convert.ToInt32(dt1.Rows[0]["med_num"]);
            }
            return num;
        }
        public static void updataUselessBY(int medid,int num)
        {
            int useID1;
            int useID;
            med_useless use = new med_useless();
            med_useless use1 = new med_useless();

           
            string sql = "select  * from med_useless where med_ID=@med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", medid) };
            using (DataTable dt = SqlHelper.GetDataSet(sql, prams))
            {

                DataTable dt1 = new DataTable();
                dt1 = dt;
                DataView dv = dt1.DefaultView;
                dv.Sort = "med_uselessdate asc";
                dt1 = dv.ToTable();
                use.MedNum = Convert.ToInt32(dt1.Rows[0]["med_num"]);
                useID = Convert.ToInt32(dt1.Rows[0]["med_uselessID"]);

                if ((use.MedNum - num) <= 0)
                {
                    string sql1 = "delete from med_useless where med_uselessID=@med_uselessID";
                    SqlParameter[] prams1 = new SqlParameter[] { new SqlParameter("@med_uselessID", useID) };
                    int i1 = SqlHelper.ExecuteCommand(sql1, prams1);
                    if ((use.MedNum - num) < 0)
                    {
                        use1.MedNum =Convert.ToInt32(dt1.Rows[1]["med_num"]);
                        useID1 = Convert.ToInt32(dt1.Rows[1]["med_uselessID"]);//ȷ��ҩƷ��������num
                        string sql2 = "UPDATE med_useless SET med_num =@med_num WHERE med_uselessID = @med_uselessID ";
                        SqlParameter[] prams2 = new SqlParameter[] { new SqlParameter("@med_uselessID", useID1),
                                                                    new SqlParameter("@med_num", use1.MedNum-(num -use.MedNum) )};
                        int i2 = SqlHelper.ExecuteCommand(sql2, prams2);
                    }
                }
                  
                if ((use.MedNum - num) > 0)
                {
                    useID1 = Convert.ToInt32(dt1.Rows[1]["med_uselessID"]);
                    string sql3 = "UPDATE med_useless SET med_num =@med_num WHERE med_uselessID = @med_uselessID ";
                    SqlParameter[] prams3 = new SqlParameter[] { new SqlParameter("@med_uselessID", useID1),
                                                                    new SqlParameter("@med_num", use.MedNum-num  )};
                    int i3 = SqlHelper.ExecuteCommand(sql3, prams3);

                }
                
                
            }
            
        }


        public static void updateMedAmount(int med_id,int Amount)
        {
            string sql = "UPDATE medicinal SET med_Amount =@med_Amount WHERE med_ID = @med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", med_id) ,
                                                        new SqlParameter("@med_Amount",Amount)};
            int i = SqlHelper.ExecuteCommand(sql, prams);

        }
        public static void updateMedNamebyID(int med_id, string medName)
        {
            string sql = "UPDATE medicinal SET med_Name =@med_Name WHERE med_ID = @med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", med_id) ,
                                                        new SqlParameter("@med_Name",medName)};
            int i = SqlHelper.ExecuteCommand(sql, prams);
        }
        public static void updateMedMomebyID(int med_id, string medMome)
        {
            string sql = "UPDATE medicinal SET med_Mome =@med_Mome WHERE med_ID = @med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", med_id) ,
                                                        new SqlParameter("@med_Mome",medMome)};
            int i = SqlHelper.ExecuteCommand(sql, prams);
        }
        public static void deleteMedBYID(int med_id)
        {
            string sql = "DELETE FROM medicinal WHERE med_ID = @med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", med_id)};
            int i = SqlHelper.ExecuteCommand(sql, prams);
        }
        public static void insmedBymed(medicinal med)
        {
            med.MedAmount=0;
            string sql = ("insert into medicinal (med_Name,med_Amount,med_Mome) values (@med_Name,@med_Amount,@med_Mome)");
            SqlParameter[] prams = new SqlParameter[] 
            {
                 new SqlParameter("@med_Name",med.MedName),
                 new SqlParameter("@med_Amount",med.MedAmount),
                 new SqlParameter("@med_Mome",med.Mome)
              
            };
            int ins = SqlHelper.ExecuteCommand(sql, prams);
        }


    }
}
