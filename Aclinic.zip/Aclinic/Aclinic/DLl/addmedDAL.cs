﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public static class addmedDAL
    {
       public static void addMeduseless(med_useless useless)
       {

           string sql = ("insert into med_useless (med_uselessdate,med_ID,med_Batch,med_buydate,med_buyprice,med_num) values (@med_uselessdate,@med_ID,@med_Batch,@med_buydate,@med_buyprice,@med_num)");
               SqlParameter[] prams = new SqlParameter[] 
            {
                 new SqlParameter("@med_uselessdate",useless.MedUselessdate),
                 new SqlParameter("@med_ID",useless.MedID),
                 
                 new SqlParameter("@med_Batch",useless.MedBath),
                 
                 new SqlParameter("@med_buydate",useless.MedByudate=DateTime.Now),
                 new SqlParameter("@med_buyprice",useless.MedBuyprice),
                 new SqlParameter("@med_num",useless.MedNum)
            };
               int ins = SqlHelper.ExecuteCommand(sql, prams);
           
       }
       
       
    }
}
