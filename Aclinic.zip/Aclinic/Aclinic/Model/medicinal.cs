using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class medicinal
    {
        private int medID;

        public int MedID
        {
            get { return medID; }
            set { medID = value; }
        }
        private string medName;

        public string MedName
        {
            get { return medName; }
            set { medName = value; }
        }
        
       
        private int medAmount;

        public int MedAmount
        {
            get { return medAmount; }
            set { medAmount = value; }
        }
     
        private string mome;

        public string Mome
        {
            get { return mome; }
            set { mome = value; }
        }
        private int medTypeID;

        public int MedTypeID
        {
            get { return medTypeID; }
            set { medTypeID = value; }
        }

    }
}
