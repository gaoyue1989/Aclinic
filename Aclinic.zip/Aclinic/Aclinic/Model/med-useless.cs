﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class med_useless
    {
        private int medID;

        public int MedID
        {
            get { return medID; }
            set { medID = value; }
        }
        private string medBath;

        public string MedBath
        {
            get { return medBath; }
            set { medBath = value; }
        }
        private DateTime medByudate;

        public DateTime MedByudate
        {
            get { return medByudate; }
            set { medByudate = value; }
        }
        private DateTime medUselessdate;

        public DateTime MedUselessdate
        {
            get { return medUselessdate; }
            set { medUselessdate = value; }
        }
        private double medBuyprice;

        public double MedBuyprice
        {
            get { return medBuyprice; }
            set { medBuyprice = value; }
        }
        private int medNum;

        public int MedNum
        {
            get { return medNum; }
            set { medNum = value; }
        }
    }
}
