using System;
using System.Collections.Generic;
using System.Text;
using DAL;
using Model;

namespace BLL
{
    public static  class userBLL
    {
        public static user GetUserByLogin(string userName)
        {
            return DAL.userDAL.GetUserByLogin(userName);
        }
    }
}
