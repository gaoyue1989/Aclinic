using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Text;

namespace BLL
{
    public static class split
    {
        public  string[] GetSpellBoxSource(DataTable dt)
        {
            //  MessageBox.Show(dt.Columns.Contains("te12xt").ToString());
            List<string> list = new List<string>();
            foreach (DataRow dr in dt.Rows)
            {
                if (!Convert.IsDBNull(dr["med_ID"]))
                    list.Add(dr["med_ID"].ToString());
            }
            return list.ToArray();
        }
        public  DataTable GetDataTable()
        {
            //�������Լ��Ĵ����������ݿ���õ�Ҫ����У�
            //������û�����ݿ⣬�������������ģ����DatatTable
            // DataTable dt = DB.GetDatatable("sql");
            DataTable dt = new DataTable();
            dt = medicinaBLL.GetallMed1();
            //dt.Columns.Add(new DataColumn("Text", typeof(string)));
            //Random rn = new Random();
            //for (int i = 0; i < 50; i++)
            //{
            //    string str = "��" + GetRandomChinese(rn.Next(8));
            //    DataRow dr = dt.NewRow();
            //    dr["Text"] = str;
            //    dt.Rows.Add(dr);
            //}
            return dt;
        }
    }
}
