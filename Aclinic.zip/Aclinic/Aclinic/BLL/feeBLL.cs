﻿using System;
using System.Collections.Generic;
using System.Text;
using DAL;
using Model;
namespace BLL
{
   public static class feeBLL
    {
       public static void insFeeByFee(fee feeinfo)
       {
           DAL.feeDAL.insFeeByFee(feeinfo);
       }
    }
}
