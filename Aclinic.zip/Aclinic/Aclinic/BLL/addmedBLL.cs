﻿using System;
using System.Collections.Generic;
using System.Text;
using Model;
namespace BLL
{
   public static class addmedBLL

    {
       public static void addMeduseless(med_useless useless)
       {
           DAL.addmedDAL.addMeduseless(useless);
       }
    }
}
