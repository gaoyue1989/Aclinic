using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DAL;
using Model;
namespace BLL
{
  public static  class treatmentBLL
    {
      public static List<treatment> GetallTreat()
      {
          return DAL.treatmentDAL.GetallTreat();
      }
      public static DataTable GetallTreat1()
        {
            return DAL.treatmentDAL.GetallTreat1();
        }

      public static treatment GetTreatBYName(string name)
      {
          return DAL.treatmentDAL.GetTreatBYName(name);
      }
    }
}
