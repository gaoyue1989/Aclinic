using System;
using System.Collections.Generic;
using System.Text;
using DAL;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public static class medicinaBLL
    {
        public static List<medicinal> GetallMedName()
        {
            return DAL.medicinalDAL.GetallMed();
        }
        public static double GetPriceBYMedID(int id)
        {
            return DAL.medicinalDAL.GetPriceBYMedID(id);
        }
        public static DataTable GetallMed1()
        {
            return DAL.medicinalDAL.GetallMed1();
        }
        public static DataTable Getalldoctor()
        {
            return DAL.medicinalDAL.Getalldoctor();
        }
        public static int GatNumBYMedName(string name)
        {
            return  DAL.medicinalDAL.GatNumBYMedName(name);
        }
        public static medicinal GatMedinfoBYmedName(string name)
        {
            return DAL.medicinalDAL.GatMedinfoBYmedName(name);
        }
        public static void UpdataMedNumBy(int medID, int Num)
        {
             DAL.medicinalDAL.updateMedAmount(medID, Num);
 
        }
    }
}
