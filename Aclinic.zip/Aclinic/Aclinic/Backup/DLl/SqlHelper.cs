using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;

namespace DAL
{
    public static class SqlHelper
    {

            private static SqlConnection connection;
            public static SqlConnection Connection
            {
                get
                {
                    string connectionString = ConfigurationManager.ConnectionStrings["Aclinic"].ConnectionString;
                    if (connection == null)
                    {
                        connection = new SqlConnection(connectionString);
                        connection.Open();
                    }
                    else if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        connection.Open();
                    }
                    else if (connection.State == System.Data.ConnectionState.Broken)
                    {
                        connection.Close();
                        connection.Open();
                    }
                    return connection;
                }
            }

            /// <summary>
            /// ִ��һ����ɾ�Ĵ洢����(�в�)
            /// </summary>
            /// <param name="procName">�洢��������</param>
            /// <param name="values">�����б�</param>
            /// <returns>Ӱ������</returns>
            public static int ExecuteProc(string procName, params SqlParameter[] values)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = Connection;
                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(values);
                return cmd.ExecuteNonQuery();
            }
            /// <summary>
            /// ִ��һ����ѯ�޲δ洢���̣�Ҫ�ر�
            /// </summary>
            /// <param name="procName">�洢��������</param>
            /// <returns>SqlDataReader</returns>
            public static SqlDataReader ExecuteProcSelect(string procName)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = Connection;
                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                return cmd.ExecuteReader();
            }
            /// <summary>
            /// ִ��һ�����β�ѯ�洢����,ע��Ҫ�ر� 
            /// </summary>
            /// <param name="procName">�洢��������</param>
            /// <param name="values">�����б�</param>
            /// <returns>SqlDataReader</returns>
            public static SqlDataReader ExecuteProcSelect(string procName, params SqlParameter[] values)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = Connection;
                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(values);
                return cmd.ExecuteReader();
            }
            /// <summary>
            /// ִ��һ���޲���ɾ�Ĵ洢����
            /// </summary>
            /// <param name="procName">�洢��������</param>
            /// <returns>Ӱ������</returns>
            public static int ExecuteProc(string procName)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = Connection;
                cmd.CommandText = procName;
                cmd.CommandType = CommandType.StoredProcedure;
                return cmd.ExecuteNonQuery();
            }
            /// <summary>
            /// ִ��һ��(�޲�)��ɾ�����
            /// </summary>
            /// <param name="safeSql">���</param>
            /// <returns>Ӱ������</returns>
            public static int ExecuteCommand(string safeSql)
            {
                SqlCommand cmd = new SqlCommand(safeSql, Connection);
                int result = cmd.ExecuteNonQuery();
                return result;
            }
            /// <summary>
            /// ִ��һ���в���ɾ�Ĳ���
            /// </summary>
            /// <param name="sql">���</param>
            /// <param name="values">����</param>
            /// <returns>Ӱ������ </returns>
            public static int ExecuteCommand(string sql, params SqlParameter[] values)
            {
                SqlCommand cmd = new SqlCommand(sql, Connection);
                cmd.Parameters.AddRange(values);
                return cmd.ExecuteNonQuery();
            }

            /// <summary>
            /// ��ѯ��һ�е�һ�����ݣ��޲Σ������ص���ʲô���;�ת����ʲô���ͣ�
            /// </summary>
            /// <param name="safeSql">���</param>
            /// <returns>object</returns>
            public static object GetScalar(string safeSql)
            {
                SqlCommand cmd = new SqlCommand(safeSql, Connection);
                return cmd.ExecuteScalar();
            }

            /// <summary>
            /// ��ѯ��һ�е�һ�����ݣ��вΣ������ص���ʲô���;�ת����ʲô���ͣ�
            /// </summary>
            /// <param name="values">����</param>
            /// <returns>object</returns>
            public static object GetScalar(string safeSql, params SqlParameter[] values)
            {
                SqlCommand cmd = new SqlCommand(safeSql, Connection);
                cmd.Parameters.AddRange(values);
                return cmd.ExecuteScalar();
            }

            /// <summary>
            /// ����һ��SqlDataReader��ע��Ҫ�رգ�
            /// </summary>
            /// <param name="safeSql">���</param>
            /// <returns>SqlDataReader</returns>
            public static SqlDataReader GetReader(string safeSql)
            {
                SqlCommand cmd = new SqlCommand(safeSql, Connection);
                SqlDataReader reader = cmd.ExecuteReader();
                return reader;
            }
            /// <summary>
            /// ����int
            /// </summary>
            /// <param name="sql"></param>
            /// <param name="values"></param>
            /// <returns></returns>
            public static int GetScalarInt(string sql, params SqlParameter[] values)
            {
                SqlCommand cmd = new SqlCommand(sql, Connection);
                cmd.Parameters.AddRange(values);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }

            /// <summary>
            /// ����string
            /// </summary>
            /// <param name="sql"></param>
            /// <param name="values"></param>
            /// <returns></returns>
            public static string GetScalarString(string sql, params SqlParameter[] values)
            {
                SqlCommand cmd = new SqlCommand(sql, Connection);
                cmd.Parameters.AddRange(values);
                return Convert.ToString(cmd.ExecuteScalar());
            }

            /// <summary>
            /// ����һ���в�SqlDataReader��ע��Ҫ�رգ�
            /// </summary>
            /// <param name="sql">���</param>
            /// <param name="values">����</param>
            /// <returns>SqlDataReader</returns>
            public static SqlDataReader GetReader(string sql, params SqlParameter[] values)
            {
                SqlCommand cmd = new SqlCommand(sql, Connection);
                cmd.Parameters.AddRange(values);
                SqlDataReader reader = cmd.ExecuteReader();
                return reader;
            }
            /// <summary>
            /// ����һ��Datatable���޲Σ�
            /// </summary>
            /// <param name="safeSql">���</param>
            /// <returns>DataTable</returns>
            public static DataTable GetDataSet(string safeSql)
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand(safeSql, Connection);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                return ds.Tables[0];
            }
            /// <summary>
            /// ����һ��Datatable���вΣ�
            /// </summary>
            /// <param name="sql">���</param>
            /// <param name="values">����</param>
            /// <returns>DataTable</returns>
            public static DataTable GetDataSet(string sql, params SqlParameter[] values)
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand(sql, Connection);
                cmd.Parameters.AddRange(values);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                return ds.Tables[0];
            }
            /// <summary>
            /// ִ�ж���SQL��䣬ʵ�����ݿ�����
            /// </summary>
            /// <param name="SQLStringList">����SQL���</param>  
            public static void ExecuteSqlTran(ArrayList SQLStringList)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = Connection;
                SqlTransaction tx = Connection.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n = 0; n < SQLStringList.Count; n++)
                    {
                        string strsql = SQLStringList[n].ToString();
                        if (strsql.Trim().Length > 1)
                        {
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                }
                catch (System.Data.SqlClient.SqlException E)
                {
                    tx.Rollback();
                    throw new Exception(E.Message);
                }
            }
        }
    }
