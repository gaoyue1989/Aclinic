using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public static class medicinalDAL
    {
        public static List<medicinal> GetallMed()
        /// <summary>
        /// �������ҩƷ��Ϣ
        /// </summary>
        /// <returns></returns>
        {
            List<medicinal> med = new List<medicinal>();
            string sql = "select * from medicinal";
            using (DataTable dt = SqlHelper.GetDataSet(sql))
            {
                foreach (DataRow row in dt.Rows)
                {
                    medicinal medinfo = new medicinal();
                    if (row["med_Name"].ToString() != null)
                    { 
                        medinfo.MedName = row["med_Name"].ToString(); 
                    }
                 
                    medinfo.MedAmount = Convert.ToInt32( row["med_Amount"].ToString());
                    medinfo.MedID = Convert.ToInt32(row["med_ID"].ToString());
                    medinfo.MedNumber = row["med_Number"].ToString();
                    medinfo.MedTypeID = Convert.ToInt32(row["med_TypeID"].ToString());
                    medinfo.MedUse = row["med_Use"].ToString();
                    medinfo.Mome = row["med_Mome"].ToString();
                    med.Add(medinfo);
                }
            }
            return med;
        }

        public static DataTable GetallMed1()
        {
            string sql = "select * from medicinal";
            DataTable dt = SqlHelper.GetDataSet(sql);
            return dt;
            

 
        }    
        public static medicinal GatMedinfoBYmedName(string name)
        {
            medicinal med = new medicinal();
            string sql = "select * from medicinal where med_Name=@med_Name";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_Name", name) };
            using (DataTable dt = SqlHelper.GetDataSet(sql, prams))
            {
                foreach (DataRow row in dt.Rows)
                {
                    medicinal medinfo = new medicinal();
                    if (row["med_Name"].ToString() != null)
                    {
                        medinfo.MedName = row["med_Name"].ToString();
                    }

                    medinfo.MedAmount = Convert.ToInt32(row["med_Amount"].ToString());
                    medinfo.MedID = Convert.ToInt32(row["med_ID"].ToString());
                    medinfo.MedNumber = row["med_Number"].ToString();
                    medinfo.MedTypeID = Convert.ToInt32(row["med_TypeID"].ToString());
                    medinfo.MedUse = row["med_Use"].ToString();
                    medinfo.Mome = row["med_Mome"].ToString();
                    med = medinfo;
 
                }
 
            }
            return med;
        }
        public static DataTable Getalldoctor()
        {
            string sql = "select * from doctor";
            DataTable dt = SqlHelper.GetDataSet(sql);
            return dt;
        }
        public static int GatNumBYMedName(string name)
        {
            int Num;
            medprice price = new medprice();
            string sql = "select med_Amount from medicinal where med_Name=@med_Name ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_Name", name) };
            Num = SqlHelper.GetScalarInt(sql, prams);
            return Num;

 
        }

        public static double GetPriceBYMedID(int id)
        {
            double price1;
            medprice price = new medprice();
            string sql = "select  * from med_price where med_ID=@med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", id) };
           using (DataTable dt = SqlHelper.GetDataSet(sql, prams))
           {
               
               DataTable dt1 = new DataTable();
               dt1 = dt;
               DataView dv = dt1.DefaultView;
               dv.Sort = "med_PriceDate desc"; 
               dt1 = dv.ToTable();
               price1 = Convert.ToDouble(dt1.Rows[0][1]);
           }
           return price1;
        }
        public static void updateMedAmount(int med_id,int Amount)
        {
            string sql = "UPDATE medicinal SET med_Amount =@med_Amount WHERE med_ID = @med_ID ";
            SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@med_ID", med_id) ,
                                                        new SqlParameter("@med_Amount",Amount)};
            int i = SqlHelper.ExecuteCommand(sql, prams);

        }

    }
}
