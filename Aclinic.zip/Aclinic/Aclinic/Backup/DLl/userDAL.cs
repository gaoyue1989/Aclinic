using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public static class userDAL
    {
       public static user GetUserByLogin(string userName)
       {
           user use = null;
           string sql = "select  * from mumber where mumber_Name=@mumber_Name ";
           SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@mumber_Name", userName) };
           using (DataTable dt = SqlHelper.GetDataSet( sql, prams))
           {
               foreach (DataRow row in dt.Rows)
               {
                   user t = new user();
                   t.UserID = Convert.ToInt32(row["mumber_ID"]);
                   t.UserPassword = row["mumber_Password"].ToString();
                   t.UserPower = Convert.ToInt32(row["mumber_Power"]);
                   use = t;
               }
           }          
               return use;
       }

    }
}
