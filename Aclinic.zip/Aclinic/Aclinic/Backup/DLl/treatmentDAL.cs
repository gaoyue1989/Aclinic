using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public static class treatmentDAL
    {
       public static List<treatment> GetallTreat() // �������ҩƷ��Ϣ    
       {
           List<treatment> treat = new List<treatment>();
           string sql = "select * from treatment";
           using (DataTable dt = SqlHelper.GetDataSet(sql))
           {
               foreach (DataRow row in dt.Rows)
               {
                   treatment treatinfo = new treatment();
                   if (row["treatment_Name"].ToString() != null)
                   {
                       treatinfo.TreatmentName = row["treatment_Name"].ToString();
                   }

                   treatinfo.TreatmentPrice = Convert.ToDouble(row["treatment_Price"].ToString());
                   treatinfo.TreatmentMome = row["treatment_Mome"].ToString();
                
                   treat.Add(treatinfo);
               }
           }
           return treat;
       }
       public static treatment GetTreatBYName(string name) 
       {
           treatment treat = new treatment();
           string sql = "select * from treatment WHERE treatment_Name=@treatment_Name";
           SqlParameter[] prams = new SqlParameter[] { new SqlParameter("@treatment_Name", name) };
           using (DataTable dt = SqlHelper.GetDataSet(sql,prams))
           {
               foreach (DataRow row in dt.Rows)
               {
                   treatment treatinfo = new treatment();
                   if (row["treatment_Name"].ToString() != null)
                   {
                       treatinfo.TreatmentName = row["treatment_Name"].ToString();
                   }

                   treatinfo.TreatmentPrice = Convert.ToDouble(row["treatment_Price"].ToString());
                   treatinfo.TreatmentMome = row["treatment_Mome"].ToString();

                   treat = treatinfo;
               }
           }
           return treat;
       }

       public static DataTable GetallTreat1()
       {
           string sql = "select * from treatment";
           DataTable dt = SqlHelper.GetDataSet(sql);
           return dt;

       }
    }
}
