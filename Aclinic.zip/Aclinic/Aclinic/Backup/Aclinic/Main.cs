using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aclinic
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            starzhendan zhendan = new starzhendan();
            zhendan.Show();
            
       
        }

        private void admin_Load(object sender, EventArgs e)
        {

        }

      
       
    }
}