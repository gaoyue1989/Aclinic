using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Aclinic
{
    public partial class zhiliaofangfa : Form
    {
        public zhiliaofangfa()
        {
            InitializeComponent();
        }

        private void zhiliaofangfa_Load(object sender, EventArgs e)
        {
            spellSearchBoxEx1.SpellSearchSource = GetSpellBoxSource(GetDataTable());
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            starzhendan zhiliao = (starzhendan)this.Owner;
            zhiliao.treatinfo = zhiliao.treatinfo+spellSearchBoxEx1.Text.Trim() + "," + "\r\n";
            this.Close();
        }
        public string[] GetSpellBoxSource(DataTable dt)
        {
            //  MessageBox.Show(dt.Columns.Contains("te12xt").ToString());
            List<string> list = new List<string>();
            foreach (DataRow dr in dt.Rows)
            {
                if (!Convert.IsDBNull(dr["treatment_Name"]))
                    list.Add(dr["treatment_Name"].ToString());
            }
            return list.ToArray();
        }
        public DataTable GetDataTable()
        {
            //�������Լ��Ĵ����������ݿ���õ�Ҫ����У�
            //������û�����ݿ⣬�������������ģ����DatatTable
            // DataTable dt = DB.GetDatatable("sql");
            DataTable dt = new DataTable();
            dt = BLL.treatmentBLL.GetallTreat1();
            //dt.Columns.Add(new DataColumn("Text", typeof(string)));
            //Random rn = new Random();
            //for (int i = 0; i < 50; i++)
            //{
            //    string str = "��" + GetRandomChinese(rn.Next(8));
            //    DataRow dr = dt.NewRow();
            //    dr["Text"] = str;
            //    dt.Rows.Add(dr);
            //}
            return dt;
        }
    }
}