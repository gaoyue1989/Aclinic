using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
   public class treatment
    {
        private int treatmentID;

        public int TreatmentID
        {
            get { return treatmentID; }
            set { treatmentID = value; }
        }
        private string treatmentName;

        public string TreatmentName
        {
            get { return treatmentName; }
            set { treatmentName = value; }
        }
        private double treatmentPrice;

        public double TreatmentPrice
        {
            get { return treatmentPrice; }
            set { treatmentPrice = value; }
        }
        private string treatmentMome;

   
        public string TreatmentMome
        {
            get { return treatmentMome; }
            set { treatmentMome = value; }
        }
    }
}
