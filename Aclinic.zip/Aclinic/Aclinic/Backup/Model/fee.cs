using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
   public class fee
    {
        private int feeID;

        public int FeeID
        {
            get { return feeID; }
            set { feeID = value; }
        }
        private double feeMoney;

        public double FeeMoney
        {
            get { return feeMoney; }
            set { feeMoney = value; }
        }
        private string feeMed;

        public string FeeMed
        {
            get { return feeMed; }
            set { feeMed = value; }
        }
        private string feeTreatment;

        public string FeeTreatment
        {
            get { return feeTreatment; }
            set { feeTreatment = value; }
        }
        private double feeMedMoney;

        public double FeeMedMoney
        {
            get { return feeMedMoney; }
            set { feeMedMoney = value; }
        }
        private double feeTreatmentMoney;

        public double FeeTreatmentMoney
        {
            get { return feeTreatmentMoney; }
            set { feeTreatmentMoney = value; }
        }
        private string feeDoctor;

        public string FeeDoctor
        {
            get { return feeDoctor; }
            set { feeDoctor = value; }
        }
        private DateTime feeDate;

        public DateTime FeeDate
        {
            get { return feeDate; }
            set { feeDate = value; }
        }



    }
}
