using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
   public class medprice
    {
        private int medID;

        public int MedID
        {
            get { return medID; }
            set { medID = value; }
        }
        private double medPrice;

        public double MedPrice
        {
            get { return medPrice; }
            set { medPrice = value; }
        }
        private DateTime medPriceDate;

        public DateTime MedPriceDate
        {
            get { return medPriceDate; }
            set { medPriceDate = value; }
        }
    }
}
