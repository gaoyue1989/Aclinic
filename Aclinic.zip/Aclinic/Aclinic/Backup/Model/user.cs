using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
   public class user
    {
       private int userID ;
       private string userName;
       private string userPassword;
       private int userPower;
       public int UserID
       {
           get { return userID; }
           set { userID = value; }
       }
       public string UserName
       {
           get { return userName; }
           set { userName = value; }
       }
       public string UserPassword
       {
           get { return userPassword; }
           set { userPassword = value; }
       }
       public int UserPower
       {
           get { return userPower; }
           set { userPower = value; }
       }
    }
}
