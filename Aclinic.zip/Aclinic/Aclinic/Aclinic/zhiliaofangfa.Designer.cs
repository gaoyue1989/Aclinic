﻿namespace Aclinic
{
    partial class zhiliaofangfa
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.spellSearchBoxEx1 = new SplitWord.SpellSearchBoxEx();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(79, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "确认";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "治疗方法：";
            // 
            // spellSearchBoxEx1
            // 
            this.spellSearchBoxEx1.Location = new System.Drawing.Point(107, 48);
            this.spellSearchBoxEx1.MaxItemCount = 5;
            this.spellSearchBoxEx1.Name = "spellSearchBoxEx1";
            this.spellSearchBoxEx1.SearchMode = SplitWord.SearchMode.StartWith;
            this.spellSearchBoxEx1.Size = new System.Drawing.Size(100, 21);
            this.spellSearchBoxEx1.SpellSearchSource = null;
            this.spellSearchBoxEx1.TabIndex = 3;
            // 
            // zhiliaofangfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 178);
            this.Controls.Add(this.spellSearchBoxEx1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "zhiliaofangfa";
            this.Text = "zhiliaofangfa";
            this.Load += new System.EventHandler(this.zhiliaofangfa_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private SplitWord.SpellSearchBoxEx spellSearchBoxEx1;

    }
}