﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Model;
using BLL;
using System.Text.RegularExpressions;

namespace Aclinic
{
    public partial class addmed : Form
    {
        
        public addmed()
        {
            InitializeComponent();
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void addmed_Load(object sender, EventArgs e)
        {
            药品名称.SpellSearchSource = GetSpellBoxSource(GetDataTable());
        }
        public string[] GetSpellBoxSource(DataTable dt)
        {
            //  MessageBox.Show(dt.Columns.Contains("te12xt").ToString());
            List<string> list = new List<string>();
            foreach (DataRow dr in dt.Rows)
            {
                if (!Convert.IsDBNull(dr["med_Name"]))
                    list.Add(dr["med_Name"].ToString());
            }
            return list.ToArray();
        }
        public DataTable GetDataTable()
        {
            //这里是自己的代码连接数据库仅得到要填的列；
            //本方法没连数据库，用随机生成中文模拟获得DatatTable
            // DataTable dt = DB.GetDatatable("sql");
            DataTable dt = new DataTable();
            dt = BLL.medicinaBLL.GetallMed1();
            //dt.Columns.Add(new DataColumn("Text", typeof(string)));
            //Random rn = new Random();
            //for (int i = 0; i < 50; i++)
            //{
            //    string str = "中" + GetRandomChinese(rn.Next(8));
            //    DataRow dr = dt.NewRow();
            //    dr["Text"] = str;
            //    dt.Rows.Add(dr);
            //}
            return dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            med_useless useless = new med_useless();
            medicinal med=new medicinal();
            med=BLL.medicinaBLL.GatMedinfoBYmedName(药品名称.Text.Trim());
            useless.MedID = med.MedID;
            try
            {
                useless.MedNum = Convert.ToInt32(药品数量.Text.Trim());
                useless.MedUselessdate=药品失效期.Value;
                useless.MedBuyprice=Convert.ToDouble(药品价格.Text);
                useless.MedBath = 药品批号.Text;
                BLL.addmedBLL.addMeduseless(useless);
                BLL.medicinaBLL.UpdataMedNumBy(med.MedID,(med.MedAmount+useless.MedNum));
                
            }
            catch
            {
                MessageBox.Show("格式输入不正确");
            } 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addmedinfo addinfo  = new addmedinfo();
            addinfo.Show();
        }


    }
}
