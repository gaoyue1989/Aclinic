using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Model;
using BLL;
namespace Aclinic
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            user t = new user();
            t = BLL.userBLL.GetUserByLogin(this.userName.Text.Trim());
            if (t == null)
            {
                        MessageBox.Show("�û����������");
            }
            else
            {
                if (this.password.Text.Trim() !=t.UserPassword.Trim() )
                {   MessageBox.Show("�����������");
                   
                }
                else
                {
                    this.DialogResult = DialogResult.OK;//�ؼ�:���õ�½�ɹ�״̬  
                    this.Close();  
                   
                 
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        
    }
}