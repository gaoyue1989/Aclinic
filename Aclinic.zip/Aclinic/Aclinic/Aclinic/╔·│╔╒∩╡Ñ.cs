﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Model;
using BLL;
namespace Aclinic
{
    public partial class 生成诊单 : Form
    {
        public DataTable dt1 = new DataTable();
        public DataTable dt2 = new DataTable();
        public 生成诊单()
        {
            InitializeComponent();
        }
        double p1 = 0;
        private void 生成诊单_Load(object sender, EventArgs e)
        {
           
            dataGridView1.DataSource = dt1;
            foreach (DataRow row in dt1.Rows)
            {
                
                int id = Convert.ToInt32(row["med_ID"].ToString());
                p1=p1+BLL.medicinaBLL.GetPriceBYMedID(id);
 
            }
            label1.Text =  BLL.medicinaBLL.GetPriceBYMedID(1).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Label lbl = new Label();
            lbl.Text = "hello";
            starzhendan frm2 = new starzhendan();
            frm2.Show();
            this.Close();
        }
    }
}