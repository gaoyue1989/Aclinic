using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Model;
using BLL;
using System.Text.RegularExpressions;
namespace Aclinic
{
    public partial class starzhendan : Form
    {
        public starzhendan()
        {
            InitializeComponent();
        }
        public string medinfo;
        public string medinfo1;
        public string treatinfo;
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void starzhendan_Load(object sender, EventArgs e)
        {
            List<medicinal> med1 = new List<medicinal>();
            med1 = BLL.medicinaBLL.GetallMedName();
            //DataGridViewComboBoxColumn dcon = new DataGridViewComboBoxColumn();
            //dcon.Name = "ѡ��";
            //dataGridView1.Columns.Insert(0, dcon);
            //dcon.DataSource = med1;
            //dcon.DisplayMember = "MedName";
            //dcon.ValueMember = "MedID";
            //Column1.DataSource = med1;
            //Column1.DisplayMember = "MedName";
            //Column1.ValueMember = "MedID";
            spellSearchBoxEx1.SpellSearchSource = GetSpellBoxSource(GetDataTable());
        }
        public string[] GetSpellBoxSource(DataTable dt)
        {
            //  MessageBox.Show(dt.Columns.Contains("te12xt").ToString());
            List<string> list = new List<string>();
            foreach (DataRow dr in dt.Rows)
            {
                if (!Convert.IsDBNull(dr["doctor_name"]))
                    list.Add(dr["doctor_name"].ToString());
            }
            return list.ToArray();
        }
        public DataTable GetDataTable()
        {
            //�������Լ��Ĵ����������ݿ���õ�Ҫ����У�
            //������û�����ݿ⣬�������������ģ����DatatTable
            // DataTable dt = DB.GetDatatable("sql");
            DataTable dt = new DataTable();
            dt = medicinaBLL.Getalldoctor();
            //dt.Columns.Add(new DataColumn("Text", typeof(string)));
            //Random rn = new Random();
            //for (int i = 0; i < 50; i++)
            //{
            //    string str = "��" + GetRandomChinese(rn.Next(8));
            //    DataRow dr = dt.NewRow();
            //    dr["Text"] = str;
            //    dt.Rows.Add(dr);
            //}
            return dt;
        }
        public bool GetDoctor(string doctorname)
        {
            bool t=false;
            foreach(string i in GetSpellBoxSource(GetDataTable()))
            {
               if(i==doctorname){ t=true;
               break;}
            }
            return t;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            double yaozongjia = 0;
            

            if (GetDoctor(spellSearchBoxEx1.Text.Trim()))
            {
            double priceall = 0;
            try
            {
                priceall = Convert.ToDouble(�ܼ�.Text.Trim());
            }
            catch
            {
                MessageBox.Show("������벻��ȷ");
            }
            string medfee="";
            fee feeinfo = new fee();
            if (medinfo != null&&priceall>0)
            {
                string[] resultString = Regex.Split(medinfo, ",\r\n", RegexOptions.IgnoreCase);
                string[] resultString1 = Regex.Split(medinfo1, ",\r\n", RegexOptions.IgnoreCase);

                for (int i = 0; i < resultString.Length; i++)
                {

                    if(resultString[i]!="")
                    {
                        
                        medfee = medfee + resultString[i] + "," + resultString1[i] + ".";
                        medicinal med = new medicinal();
                        int Num = Convert.ToInt32(resultString1[i]);
                        med = BLL.medicinaBLL.GatMedinfoBYmedName(resultString[i]);
                        if (BLL.medicinaBLL.GatNumBYMedid(med.MedID)<Num)
                        {
 
                        }
                        
                        int Amount = med.MedAmount - Num;
                        BLL.medicinaBLL.UpdataMedNumBy(med.MedID, Amount);
                        //����med�� ��useless������������
                        
                        BLL.medicinaBLL.updataUselessBY(med.MedID, Num);
                        double price = BLL.medicinaBLL.GetPriceBYMedID(med.MedID);
                        yaozongjia = price * Num + yaozongjia;
                        
                    }
                  
                } 
                    feeinfo.FeeDoctor = spellSearchBoxEx1.Text.Trim();
                    feeinfo.FeeDate = DateTime.Now;
                    feeinfo.FeeMed = medfee;
                    feeinfo.FeeMedMoney = yaozongjia;
                    feeinfo.FeeMoney = priceall;
                    BLL.feeBLL.insFeeByFee(feeinfo);
                    this.Close();
                   
            }
            //if (treatinfo != null)
            //{
            //    string[] resultString3 = Regex.Split(treatinfo, ",\r\n", RegexOptions.IgnoreCase);
            //    foreach (string i in resultString3)
            //    {
            //        if (i != "")
            //        {
            //            treatfee = treatfee + i+",";
                        

            //        }
            //    }
            //}
          
            
            
            
            
           }
            else MessageBox.Show("ҽʦ����δע��");


        }

        private void button2_Click(object sender, EventArgs e)
        {
            yaopinxuanze yao = new yaopinxuanze();
            yao.Owner = this;
            yao.ShowDialog();
            yao.Dispose();
            label4.Text = medinfo;
            label6.Text = medinfo1;


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        //private void button3_Click(object sender, EventArgs e)
        //{
        //    zhiliaofangfa zhiliao = new zhiliaofangfa();
        //    zhiliao.Owner = this;
        //    zhiliao.ShowDialog();
        //    zhiliao.Dispose();
        //    //label3.Text = treatinfo;
        //}

        private void button4_Click(object sender, EventArgs e)
        {
            
                //double yaozongjia = 0;
                //string yaodanjia = null;
                //double zhizongjia = 0;
                //string zhiliaojia = null;

                if (medinfo == null )
                {
                   button1.Enabled = false;
                }
                else
                {

                    button1.Enabled =true;
                    //if (medinfo != null)
                    //{
                    //    string[] resultString = Regex.Split(medinfo, ",\r\n", RegexOptions.IgnoreCase);
                    //    string[] resultString1 = Regex.Split(medinfo1, ",\r\n", RegexOptions.IgnoreCase);

                    //    for (int i = 0; i < resultString.Length; i++)
                    //    {


                    //        if (resultString[i] != "")
                    //        {
                    //            medicinal med = new medicinal();
                    //            med = BLL.medicinaBLL.GatMedinfoBYmedName(resultString[i]);
                    //            int Num = Convert.ToInt32(resultString1[i]);

                    //            double price = BLL.medicinaBLL.GetPriceBYMedID(med.MedID);
                    //            yaodanjia = yaodanjia + price.ToString("C") + "\r\n";
                    //            yaozongjia = price * Num + yaozongjia;

                    //        }
                    //    }

                    //}

                    //if (treatinfo != null)
                    //{

                    //    string[] resultString3 = Regex.Split(treatinfo, ",\r\n", RegexOptions.IgnoreCase);
                    //    foreach (string i in resultString3)
                    //    {
                    //        if (i != "")
                    //        {
                    //            treatment treat = new treatment();
                    //            treat = BLL.treatmentBLL.GetTreatBYName(i);
                    //            zhiliaojia = zhiliaojia + treat.TreatmentPrice.ToString("C") + "\r\n";
                    //            zhizongjia = zhizongjia + treat.TreatmentPrice;

                    //        }
                    //    }


                    //}
                    //double zong = zhizongjia + yaozongjia;
                    //if (zong != 0) button1.Enabled = true;
                    //else 
                    //�ܻ���.Text = zong.ToString("C");
                    //���Ƶ���.Text = zhiliaojia;
                    //ҩƷ�ϼ�.Text = yaozongjia.ToString("C");
                    //ҩƷ����.Text = yaodanjia;

                    //���ƺϼ�.Text = zhizongjia.ToString("C");
                }
            

        }


        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
              
        }

        private void button6_Click(object sender, EventArgs e)
        {
            treatinfo = null;
            //label3.Text = treatinfo;
            medinfo=null;
                medinfo1=null;
                label4.Text = medinfo;
                label6.Text = medinfo1;
                �ܻ���.Text = null;
                //���Ƶ���.Text = null;
                //ҩƷ�ϼ�.Text = null;
                //ҩƷ����.Text = null;

                //���ƺϼ�.Text = null;
                button1.Enabled = false;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (GetDoctor(spellSearchBoxEx1.Text)) MessageBox.Show("��������");
                else MessageBox.Show("����������");
        }


    }

        public class DataTransition
        {
            /// <summary>
            /// datagridviewתdatatable
            /// </summary>
            /// <param name="dv"></param>
            /// <returns></returns>
            public static DataTable dvtodt(DataGridView dv)
            {
                DataTable dt = new DataTable();
                DataColumn dc;
                for (int i = 0; i < dv.Columns.Count; i++)
                {
                    dc = new DataColumn();
                    dc.ColumnName = dv.Columns[i].HeaderText.ToString();
                    dt.Columns.Add(dc);
                }
                for (int j = 0; j < dv.Rows.Count; j++)
                {
                    DataRow dr = dt.NewRow();
                    for (int x = 0; x < dv.Columns.Count; x++)
                    {
                        dr[x] = dv.Rows[j].Cells[x].Value;
                    }
                    dt.Rows.Add(dr);
                }
                return dt;
            }
        }
    
}