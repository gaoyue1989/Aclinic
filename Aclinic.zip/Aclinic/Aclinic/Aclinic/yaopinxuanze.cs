using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace Aclinic
{
    
    public partial class yaopinxuanze : Form
    {
        public yaopinxuanze()
        {
            InitializeComponent();
           
        }
       
        public string[] GetSpellBoxSource(DataTable dt)
        {
            //  MessageBox.Show(dt.Columns.Contains("te12xt").ToString());
            List<string> list = new List<string>();
            foreach (DataRow dr in dt.Rows)
            {
                if (!Convert.IsDBNull(dr["med_Name"]))
                    list.Add(dr["med_Name"].ToString());
            }
            return list.ToArray();
        }
        public DataTable GetDataTable()
        {
            //�������Լ��Ĵ����������ݿ���õ�Ҫ����У�
            //������û�����ݿ⣬�������������ģ����DatatTable
            // DataTable dt = DB.GetDatatable("sql");
            DataTable dt = new DataTable();
            dt = BLL.medicinaBLL.GetallMed1();
            //dt.Columns.Add(new DataColumn("Text", typeof(string)));
            //Random rn = new Random();
            //for (int i = 0; i < 50; i++)
            //{
            //    string str = "��" + GetRandomChinese(rn.Next(8));
            //    DataRow dr = dt.NewRow();
            //    dr["Text"] = str;
            //    dt.Rows.Add(dr);
            //}
            return dt;
        }
        //private void spellSearchBoxEx1_Leave(object sender, EventArgs e)
        //{
        //    //label4.Text=BLL.medicinaBLL.GatNumBYMedName( spellSearchBoxEx1.Text.Trim());
        //    label4.Text = "1222";
            
        //    // do
        //}

        private void yaopinxuanze_Load(object sender, EventArgs e)
        {
             spellSearchBoxEx1.SpellSearchSource = GetSpellBoxSource(GetDataTable());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //try
            //{
            if (BLL.medicinaBLL.GatNumBYMedName(spellSearchBoxEx1.Text.Trim()) - Convert.ToInt32(numericUpDown1.Value) < 0 || BLL.medicinaBLL.GatNumBYMedName(spellSearchBoxEx1.Text.Trim()) == 0)
            {
                MessageBox.Show("ҩƷ��治���򲻴���");
            }
            else
            {
                if (numericUpDown1.Value== 0) 
                {
                    MessageBox.Show("û������ҩƷ����");
                }
                else
                {
                    starzhendan zhendan = (starzhendan)this.Owner;
                    medinfo med = new medinfo();
                    med.Medname = spellSearchBoxEx1.Text.Trim();
                    med.MedNum = numericUpDown1.Value.ToString();
                    zhendan.medinfo = zhendan.medinfo + med.Medname + "," + "\r\n";
                    zhendan.medinfo1 = zhendan.medinfo1 + med.MedNum + "," + "\r\n";
                    this.Close();
                }

            } 
            //}
            //catch
            //{
            //    MessageBox.Show("ҩƷ������");
            //}
        }
    }
    public class medinfo
    {
        private string medname;

        public string Medname
        {
            get { return medname; }
            set { medname = value; }
        }
        private string medNum;

        public string MedNum
        {
            get { return medNum; }
            set { medNum = value; }
        }
    }
}