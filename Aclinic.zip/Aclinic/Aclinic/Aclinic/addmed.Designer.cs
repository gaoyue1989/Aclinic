﻿namespace Aclinic
{
    partial class addmed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.药品名称 = new SplitWord.SpellSearchBoxEx();
            this.药品数量 = new System.Windows.Forms.TextBox();
            this.药品价格 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.药品批号 = new System.Windows.Forms.TextBox();
            this.药品失效期 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lable1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "添加药品";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.药品名称);
            this.groupBox1.Controls.Add(this.药品数量);
            this.groupBox1.Controls.Add(this.药品价格);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.药品批号);
            this.groupBox1.Controls.Add(this.药品失效期);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lable1);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox1.Location = new System.Drawing.Point(13, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(463, 308);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "进药信息录入";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // 药品名称
            // 
            this.药品名称.Location = new System.Drawing.Point(101, 20);
            this.药品名称.MaxItemCount = 5;
            this.药品名称.Name = "药品名称";
            this.药品名称.SearchMode = SplitWord.SearchMode.StartWith;
            this.药品名称.Size = new System.Drawing.Size(242, 26);
            this.药品名称.SpellSearchSource = null;
            this.药品名称.TabIndex = 10;
            // 
            // 药品数量
            // 
            this.药品数量.Location = new System.Drawing.Point(101, 209);
            this.药品数量.Name = "药品数量";
            this.药品数量.Size = new System.Drawing.Size(100, 26);
            this.药品数量.TabIndex = 9;
            // 
            // 药品价格
            // 
            this.药品价格.Location = new System.Drawing.Point(101, 153);
            this.药品价格.Name = "药品价格";
            this.药品价格.Size = new System.Drawing.Size(100, 26);
            this.药品价格.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "药品数量：";
            // 
            // 药品批号
            // 
            this.药品批号.Location = new System.Drawing.Point(101, 58);
            this.药品批号.Name = "药品批号";
            this.药品批号.Size = new System.Drawing.Size(242, 26);
            this.药品批号.TabIndex = 5;
            // 
            // 药品失效期
            // 
            this.药品失效期.Location = new System.Drawing.Point(101, 104);
            this.药品失效期.Name = "药品失效期";
            this.药品失效期.Size = new System.Drawing.Size(148, 26);
            this.药品失效期.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "药品价格：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "药品失效期：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "药品批号：";
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Location = new System.Drawing.Point(7, 26);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(88, 16);
            this.lable1.TabIndex = 0;
            this.lable1.Text = "药品名称：";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(257, 256);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 32);
            this.button2.TabIndex = 11;
            this.button2.Text = "确定";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // addmed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 361);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Name = "addmed";
            this.Text = "addmed";
            this.Load += new System.EventHandler(this.addmed_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lable1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox 药品批号;
        private System.Windows.Forms.DateTimePicker 药品失效期;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox 药品数量;
        private System.Windows.Forms.TextBox 药品价格;
        private SplitWord.SpellSearchBoxEx 药品名称;
        private System.Windows.Forms.Button button2;
    }
}